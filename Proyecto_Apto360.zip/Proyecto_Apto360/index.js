import React from 'react';
import {
  AppRegistry,
  StyleSheet,
  Text,
  View,
  VrButton
} from 'react-360';

import {connect, changeRoom} from './store';

export default class Buttons extends React.Component {
  state = {
    hover: false 
  }
  clickHandler(roomSelection){
    changeRoom(roomSelection);
  }

  createRoomButtons(adjacentRooms){
    let rooms = adjacentRooms;
    let buttons = [];

    rooms.map(room=>(
      buttons.push(
        <VrButton style={this.state.hover ? styles.hover : styles.button} 
                  key={`${room}`+'-button'} onClick={()=>this.clickHandler(room)}
                  onEnter={()=> this.setState({hover:true})}
                  onExit={()=>this.setState({hover:false})}>
          <Text style={{textAlign: 'center'}}>{room}</Text>
        </VrButton>
      )
    ));

    return buttons;
  }

  render() {
    return (
      <View style={styles.buttonPanel}>
        <View style={styles.header}>
          <Text>
            Room Selection
          </Text>
          <Text>
            { this.props.room }
          </Text>
          {this.createRoomButtons(this.props.adjacentRooms)}
        </View>              
      </View>
    );
  }
};

export class AptoInfoPanel extends React.Component {
  render() {
    return (
      <View style={styles.infoPanel}>        
        <View style={styles.header}>
          <Text>
            Room Info
          </Text>
          <Text style={{fontSize: 20, textAlign: 'left', fontWeight: 'bold'}}>
            { this.props.info }
          </Text>
        </View>        
      </View>
    );
  }
};

const ConnectedButtons = connect(Buttons);
const ConnectedAptoInfoPanel = connect(AptoInfoPanel);

const styles = StyleSheet.create({
  panel: {
    // Fill the entire surface
    width: 800,
    height: 500,
    backgroundColor: 'rgba(0, 153, 153, 1)',
    flexDirection: 'row',
    justifyContent: 'space-between'
  },
  greetingBox: {
    //width: 200,
    padding: 20,
    backgroundColor: '#000000',
    borderColor: '#639dda',
    borderWidth: 2,
  },
  greeting: {
    fontSize: 30,
  },
  hover:{
    width: 200,
    backgroundColor: 'rgb(0, 45, 72)',
    borderColor: 'rgb(255, 255, 255)',
    borderWidth: 5,
  },
  button:{
    width: 200,
    backgroundColor: 'rgb(0,0,0)',
    borderColor: 'rgb(255, 255, 255)',
    borderWidth: 5,
  },
  infoPanel: {
    width: 300,
    height: 200,
    opacity: 0.8,
    backgroundColor: 'rgba(169, 204, 227, 1)',
    borderColor: 'rgb(255, 255, 255)',
    borderWidth: 5,
    borderRadius: 20,
    flexDirection: 'column',
    justifyContent: 'space-around',
    alignItems: 'center'
  },
  buttonPanel: {
    width: 300,
    height: 200,
    opacity: 0.8,
    backgroundColor: 'rgba(169, 204, 227, 1)',
    borderColor: 'rgb(255, 255, 255)',
    borderWidth: 5,
    borderRadius: 20,
    flexDirection: 'column',
    justifyContent: 'space-around',
    alignItems: 'center'
  },
  header: {
    fontSize: 40,
    fontWeight: 'bold',
    textAlign: 'center'
  }
});

AppRegistry.registerComponent('ConnectedButtons', () => ConnectedButtons);
AppRegistry.registerComponent('ConnectedAptoInfoPanel', () => ConnectedAptoInfoPanel);
