export default apto = {
    
    Sala: {
      roomName: 'Sala' ,
      info: `
        * Amplio espacio
        * Ventana con vista al parque
        * Entra bastante luz natural
        * Totalmente pintado`,
      img: 'Sala.jpg',
      adjacentRooms: ['Cocina', 'Pasillo']
    },
    Cocina: {
      roomName: 'Cocina',
      info:`
        * Cocina Integral
        * Ventana con vista al parque.
        * Tiene gabinetes amplios.
        * Estufa eléctrica.`,
      img: 'Cocina.jpg',
      adjacentRooms: ['Sala']
    },
    Pasillo: {
      roomName: 'Pasillo',
      info: `
        * Pasillo que conecta con las habitaciones.
        * Totalmente iluminado.`,
      img: 'Pasillo.jpg',
      adjacentRooms: ['Sala','Habitacion']
    },
    Habitacion: {
      roomName: 'Habitacion',
      info: `
        * Closet amplio incluido
        * Espacio para una cama sencilla.
        * Ventana con vista al parque `,
      img: 'habitacion.jpg',
      adjacentRooms: ['Pasillo']
    }
    }
  